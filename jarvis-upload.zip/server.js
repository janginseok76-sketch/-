// ======================================================
// 자비스 (4대장 AI) — Ver 2
// Claude + GPT + Gemini + Grok 동시 호출 → 심판 AI가 최종 종합
// Node.js 18+ / 추가 패키지 없음 / 실행: node server.js
// ======================================================

const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

// ---------------- .env 읽기 ----------------
const envPath = path.join(__dirname, ".env");
if (fs.existsSync(envPath)) {
  for (const line of fs.readFileSync(envPath, "utf8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && !process.env[m[1]]) {
      process.env[m[1]] = m[2].replace(/\s+#.*$/, "").replace(/^#.*$/, "").trim().replace(/^["']|["']$/g, "");
    }
  }
}
const E = process.env;

const PORT = Number(E.PORT || 3000);
const TIMEOUT_MS = Number(E.TIMEOUT_MS || 90000);  // AI 한 번 호출의 최대 대기 시간
const RETRIES = Number(E.RETRIES || 1);             // 일시적 오류 때 다시 시도하는 횟수
const MAX_OUTPUT = Number(E.MAX_OUTPUT || 3000);    // AI별 최대 출력 토큰 (비용 관리)
const RATE_LIMIT = Number(E.RATE_LIMIT || 10);      // 1분에 한 사람이 보낼 수 있는 질문 수
const MAX_BODY = 2 * 1024 * 1024;
const MAX_HISTORY = 12;
const MAX_QUESTION = 30000;

// ---------------- 네 AI의 역할 ----------------
const ROLE = {
  claude: "논리, 정확성, 세부 검증, 위험 요소 분석",
  gpt: "실용적 해결책, 폭넓은 지식, 단계별 실행 방법",
  gemini: "자료 분석, 기술적 관점, 정보와 수치 비교",
  grok: "비판적 사고, 반대 의견, 창의적 대안",
};
const BASE_SYSTEM = (role) => `당신은 '자비스' 팀의 전문가입니다.
당신의 역할: ${role}

규칙:
1. 사용자의 언어(기본 한국어)로 답하세요.
2. 핵심부터 답하세요.
3. 모르는 사실을 지어내지 마세요.
4. 사실과 추측을 구분해서 쓰세요.
5. 불필요한 반복을 피하세요.`;

// ---------------- API 호출 (시간 제한 + 재시도) ----------------
async function postJSON(url, headers, body) {
  let lastError;
  for (let attempt = 0; attempt <= RETRIES; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { "content-type": "application/json", ...headers },
        body: JSON.stringify(body),
        signal: controller.signal,
      });
      const raw = await res.text();
      let data;
      try { data = JSON.parse(raw); } catch { data = { raw }; }
      if (!res.ok) {
        const msg = data?.error?.message || data?.error || data?.raw || res.statusText;
        const err = new Error(`${res.status} ${typeof msg === "string" ? msg : JSON.stringify(msg)}`.slice(0, 250));
        err.status = res.status;
        throw err;
      }
      return data;
    } catch (err) {
      lastError = err.name === "AbortError" ? Object.assign(new Error("응답 시간 초과"), { timeout: true }) : err;
      // 키 오류·잘못된 모델명(4xx)은 다시 해도 똑같으니 바로 멈추고, 429·5xx·네트워크 오류만 재시도
      const retryable = !err.status || err.status === 429 || err.status >= 500;
      if (!retryable || attempt === RETRIES) break;
      await new Promise((r) => setTimeout(r, 800 * (attempt + 1)));
    } finally {
      clearTimeout(timer);
    }
  }
  throw lastError || new Error("API 호출 실패");
}

// ---------------- 공급사별 호출 ----------------
// 모델명은 .env에서 바꿀 수 있어요. 빈칸이면 아래 기본값을 씁니다.
const PROVIDERS = {
  claude: {
    name: "Claude", key: () => E.ANTHROPIC_API_KEY, model: () => E.CLAUDE_MODEL || "claude-sonnet-5-5",
    async call(system, history) {
      const d = await postJSON("https://api.anthropic.com/v1/messages",
        { "x-api-key": E.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
        { model: this.model(), max_tokens: MAX_OUTPUT, system, messages: history });
      return (d.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n");
    },
  },
  gpt: {
    name: "GPT", key: () => E.OPENAI_API_KEY, model: () => E.GPT_MODEL || "gpt-6-luna",
    async call(system, history) {
      const d = await postJSON("https://api.openai.com/v1/chat/completions",
        { authorization: `Bearer ${E.OPENAI_API_KEY}` },
        { model: this.model(), max_completion_tokens: MAX_OUTPUT,
          messages: [{ role: "developer", content: system }, ...history] });
      return d.choices?.[0]?.message?.content || "";
    },
  },
  gemini: {
    name: "Gemini", key: () => E.GEMINI_API_KEY, model: () => E.GEMINI_MODEL || "gemini-flash-latest",
    async call(system, history) {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(this.model())}:generateContent`;
      const d = await postJSON(url, { "x-goog-api-key": E.GEMINI_API_KEY }, {
        systemInstruction: { parts: [{ text: system }] },
        contents: history.map((m) => ({ role: m.role === "assistant" ? "model" : "user", parts: [{ text: m.content }] })),
        generationConfig: { maxOutputTokens: MAX_OUTPUT },
      });
      return (d.candidates?.[0]?.content?.parts || []).map((p) => p.text || "").join("");
    },
  },
  grok: {
    name: "Grok", key: () => E.XAI_API_KEY, model: () => E.GROK_MODEL || "grok-4-latest",
    async call(system, history) {
      const d = await postJSON("https://api.x.ai/v1/chat/completions",
        { authorization: `Bearer ${E.XAI_API_KEY}` },
        { model: this.model(), max_tokens: MAX_OUTPUT,
          messages: [{ role: "system", content: system }, ...history] });
      return d.choices?.[0]?.message?.content || "";
    },
  },
};
const ready = (id) => !!(PROVIDERS[id] && PROVIDERS[id].key() && PROVIDERS[id].model());

// ---------------- AI 한 개 실행 ----------------
async function askOne(id, history) {
  const p = PROVIDERS[id];
  const started = Date.now();
  if (!p.key()) return { id, name: p.name, ok: false, skipped: true, error: "API 키 없음 (자동 제외)", ms: 0 };
  try {
    const text = await p.call(BASE_SYSTEM(ROLE[id]), history);
    if (!text || !text.trim()) throw new Error("빈 응답");
    return { id, name: p.name, model: p.model(), ok: true, text, ms: Date.now() - started };
  } catch (err) {
    return { id, name: p.name, model: p.model(), ok: false, error: err.message, ms: Date.now() - started };
  }
}

// ---------------- 심판 AI ----------------
const JUDGE_SYSTEM = `당신은 '자비스'의 최종 심판입니다.
여러 AI의 답변을 비교해 가장 정확하고 유용한 답변 하나를 만드세요.

규칙:
1. 틀린 정보와 근거 없는 주장은 빼세요.
2. 서로 충돌하면 근거가 더 분명한 쪽을 택하고, 정말 의견이 갈리면 짧게 밝히세요.
3. 검증할 수 없는 내용은 사실처럼 단정하지 마세요.
4. 각 AI의 답변에 없는 새로운 사실을 지어내 덧붙이지 마세요.
5. 겹치는 내용은 한 번만 쓰세요.
6. 사용자의 언어로, 질문에 대한 답부터 쓰세요.
7. 맨 끝에 '종합 메모: …' 한 줄로 어떤 AI의 어떤 점을 반영했는지 적으세요.`;

async function synthesize(question, answers) {
  const good = answers.filter((a) => a.ok && a.text);
  if (!good.length) return { ok: false, error: "모든 AI가 응답하지 못했어요. 키와 모델명을 확인해 주세요." };
  if (good.length === 1) return { ok: true, judge: `${good[0].name} 단독 응답`, text: good[0].text };

  // 심판 실패에 대비한 대체 답: .env의 JUDGE 순서대로, 성공한 답 중 첫 번째
  const order = [E.JUDGE || "claude", "claude", "gpt", "gemini", "grok"];
  const fallback = order.map((id) => good.find((a) => a.id === id)).find(Boolean) || good[0];

  const judgeId = order.find(ready);
  if (!judgeId) return { ok: true, judge: `${fallback.name} 답변 (심판 없음)`, text: fallback.text };

  const block = good.map((a) => `### ${a.name} (${a.model})의 답\n${a.text}`).join("\n\n");
  const prompt = `[사용자 질문]\n${question}\n\n[각 AI의 답변]\n${block}\n\n위 답변들을 검토해 최종 답변을 작성하세요.`;
  try {
    const text = await PROVIDERS[judgeId].call(JUDGE_SYSTEM, [{ role: "user", content: prompt }]);
    if (!text || !text.trim()) throw new Error("심판 빈 응답");
    return { ok: true, judge: PROVIDERS[judgeId].name, text };
  } catch (err) {
    return { ok: true, judge: `${fallback.name} 답변 (대체)`, text: fallback.text,
             warning: `심판 AI가 실패해서 ${fallback.name}의 답을 그대로 보여 드려요.` };
  }
}

// ---------------- 요청 처리 도구 ----------------
function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0; let done = false;
    req.on("data", (c) => {
      size += c.length;
      if (size > MAX_BODY && !done) { done = true; reject(Object.assign(new Error("요청이 너무 커요."), { status: 413 })); req.destroy(); return; }
      chunks.push(c);
    });
    req.on("end", () => {
      if (done) return;
      try { resolve(JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}")); }
      catch { reject(Object.assign(new Error("잘못된 요청 형식이에요."), { status: 400 })); }
    });
    req.on("error", (e) => { if (!done) reject(e); });
  });
}
function send(res, status, data) {
  if (res.destroyed || res.writableEnded) return;
  res.writeHead(status, { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", "x-content-type-options": "nosniff" });
  res.end(JSON.stringify(data));
}
// 비밀번호 비교: 길이와 상관없이 같은 시간이 걸리도록 해시해서 비교
function passwordOk(given) {
  if (!E.APP_PASSWORD) return true;
  const a = crypto.createHash("sha256").update(String(given || "")).digest();
  const b = crypto.createHash("sha256").update(E.APP_PASSWORD).digest();
  return crypto.timingSafeEqual(a, b);
}
// 접속한 사람의 IP. Render 같은 서버 서비스 뒤에서는 x-forwarded-for의 첫 값이 실제 IP
function clientIp(req) {
  const fwd = String(req.headers["x-forwarded-for"] || "").split(",")[0].trim();
  return fwd || req.socket.remoteAddress || "unknown";
}
const hits = new Map();
function rateLimit(req) {
  const ip = clientIp(req), now = Date.now();
  const recent = (hits.get(ip) || []).filter((t) => now - t < 60000);
  if (recent.length >= RATE_LIMIT) { hits.set(ip, recent); return false; }
  recent.push(now); hits.set(ip, recent);
  if (hits.size > 5000) for (const [k, v] of hits) if (!v.some((t) => now - t < 60000)) hits.delete(k);
  return true;
}
function cleanHistory(history) {
  if (!Array.isArray(history)) return null;
  return history
    .filter((m) => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string" && m.content.trim())
    .slice(-MAX_HISTORY)
    .map((m) => ({ role: m.role, content: m.content.slice(0, 12000) }));
}
async function readAsk(req, res) {
  if (!passwordOk(req.headers["x-app-password"])) { send(res, 401, { error: "비밀번호가 맞지 않아요." }); return null; }
  if (!rateLimit(req)) { send(res, 429, { error: "질문이 너무 많아요. 1분 뒤에 다시 보내 주세요." }); return null; }
  const body = await readBody(req);
  const q = typeof body.question === "string" ? body.question.trim() : "";
  if (!q) { send(res, 400, { error: "질문이 비어 있어요." }); return null; }
  if (q.length > MAX_QUESTION) { send(res, 413, { error: "질문이 너무 길어요." }); return null; }
  const history = cleanHistory(body.history || []);
  if (!history) { send(res, 400, { error: "대화 기록 형식이 잘못되었어요." }); return null; }
  return { body, question: q, msgs: [...history, { role: "user", content: q }] };
}

// ---------------- HTTP 서버 ----------------
const server = http.createServer(async (req, res) => {
  try {
    const url = req.url.split("?")[0];

    if (req.method === "GET" && (url === "/" || url === "/index.html")) {
      // public 폴더 안이나, server.js와 같은 곳에 있는 index.html을 찾음
      const file = [path.join(__dirname, "public", "index.html"), path.join(__dirname, "index.html")].find((f) => fs.existsSync(f));
      if (!file) return send(res, 404, { error: "index.html 파일이 없어요." });
      res.writeHead(200, { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" });
      return fs.createReadStream(file).pipe(res);
    }

    if (req.method === "GET" && url === "/api/status") {
      return send(res, 200, Object.fromEntries(Object.entries(PROVIDERS).map(([id, p]) =>
        [id, { name: p.name, ready: ready(id), model: p.model() }])));
    }

    // 네 AI 동시 호출 + 심판
    if (req.method === "POST" && url === "/api/ask") {
      const r = await readAsk(req, res); if (!r) return;
      const started = Date.now();
      const answers = await Promise.all(Object.keys(PROVIDERS).map((id) => askOne(id, r.msgs)));
      const final = await synthesize(r.question, answers);
      return send(res, 200, { version: "2.0", final, answers,
        stats: { totalMs: Date.now() - started, success: answers.filter((a) => a.ok).length,
                 failed: answers.filter((a) => !a.ok && !a.skipped).length, skipped: answers.filter((a) => a.skipped).length } });
    }

    // 실패한 AI 하나만 다시 부르기: { question, history, id: "grok" }
    if (req.method === "POST" && url === "/api/retry") {
      const r = await readAsk(req, res); if (!r) return;
      const id = r.body.id;
      if (!PROVIDERS[id]) return send(res, 400, { error: "알 수 없는 AI예요." });
      return send(res, 200, { answer: await askOne(id, r.msgs) });
    }

    // 답 목록을 다시 종합하기: { question, answers: [...] }
    if (req.method === "POST" && url === "/api/judge") {
      const r = await readAsk(req, res); if (!r) return;
      const list = Array.isArray(r.body.answers) ? r.body.answers : [];
      const safe = list.filter((a) => a && PROVIDERS[a.id] && a.ok && typeof a.text === "string")
        .map((a) => ({ id: a.id, name: PROVIDERS[a.id].name, model: String(a.model || ""), ok: true, text: a.text.slice(0, 20000), ms: Number(a.ms) || 0 }));
      return send(res, 200, { final: await synthesize(r.question, safe) });
    }

    return send(res, 404, { error: "없는 주소예요." });
  } catch (err) {
    if (err.status) return send(res, err.status, { error: err.message });
    console.error(err);
    return send(res, 500, { error: "서버 내부 오류", detail: E.NODE_ENV === "development" ? err.message : undefined });
  }
});

server.listen(PORT, () => {
  console.log("================================");
  console.log(`  자비스 Ver 2 실행 → http://localhost:${PORT}`);
  console.log("================================");
  for (const [id, p] of Object.entries(PROVIDERS)) console.log(`  ${p.name.padEnd(7)} ${ready(id) ? "준비됨" : "키 없음"}  (${p.model()})`);
  console.log(`  심판: ${E.JUDGE || "claude"} · 비밀번호: ${E.APP_PASSWORD ? "설정됨" : "없음(누구나 사용 가능)"}`);
});
